"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"

export default function Page() {
  const [downloading, setDownloading] = useState(false)

  async function handleDownloadPptx() {
    try {
      setDownloading(true)
      const { default: PptxGenJS } = await import("pptxgenjs")
      const pptx = new PptxGenJS()

      // Theme helpers
      const primary = "203A8C" // deep academic blue
      const neutral = "222222" // dark gray for text
      const accent = "0E8F8F" // teal accent
      const bg = "FFFFFF" // white

      pptx.author = "MUHAMMAD SAIF AMIR"
      pptx.company = "UET Taxila"
      pptx.subject = "MS PowerPoint – Lab 4"
      pptx.title = "MS PowerPoint – Lab 4 (Fall 2025)"

      function addTitle(slide: any, text: string) {
        slide.addText(text, {
          x: 0.5,
          y: 0.4,
          w: 9,
          h: 0.8,
          fontFace: "Arial",
          fontSize: 32,
          color: primary,
          bold: true,
        })
        // Attempt smooth transition (ignored by some viewers but harmless)
        // @ts-ignore
        slide.transition = { type: "fade" }
      }

      function addBullets(slide: any, bullets: string[], yStart = 1.5) {
        slide.addText(
          bullets.map((t) => ({ text: t, options: { bullet: true } })),
          {
            x: 0.7,
            y: yStart,
            w: 8.6,
            h: 5,
            fontFace: "Arial",
            fontSize: 20,
            color: neutral,
            lineSpacing: 18,
          },
        )
      }

      function addFooter(slide: any) {
        slide.addText("Fall Semester 2025 · UET Taxila", {
          x: 0.5,
          y: 6.7,
          w: 9,
          fontFace: "Arial",
          fontSize: 12,
          color: accent,
        })
      }

      // 1) Cover
      {
        const s = pptx.addSlide()
        s.background = { color: bg }
        addTitle(s, "MS PowerPoint – Lab 4")
        s.addText("Application of Information and Communication (Lab 4)", {
          x: 0.5,
          y: 1.3,
          w: 9,
          fontFace: "Arial",
          fontSize: 18,
          color: neutral,
        })
        s.addShape(pptx.ShapeType.rect, {
          x: 0.5,
          y: 2.1,
          w: 9,
          h: 0.02,
          fill: { color: primary },
          line: { color: primary },
        })
        s.addText(
          [
            { text: "Submitted to: ", options: { bold: true, color: neutral } },
            { text: "DR. MUHAMMAD ASIF KHAN\n", options: { color: neutral } },
            { text: "Name: ", options: { bold: true, color: neutral } },
            { text: "MUHAMMAD SAIF AMIR\n", options: { color: neutral } },
            { text: "Registration No: ", options: { bold: true, color: neutral } },
            { text: "25-ENV-56\n", options: { color: neutral } },
            { text: "Date: ", options: { bold: true, color: neutral } },
            { text: "03/10/2025\n", options: { color: neutral } },
          ],
          { x: 0.5, y: 2.4, w: 9, fontFace: "Arial", fontSize: 18 },
        )
        s.addNotes("Cover slide with student and course details.")
        addFooter(s)
      }

      // 2) Objectives
      {
        const s = pptx.addSlide()
        s.background = { color: bg }
        addTitle(s, "Objectives")
        addBullets(s, [
          "Creating Tables (insert, format, import)",
          "Creating Charts (insert, edit data, modify)",
          "Slide Transitions (effects, timing, apply to all)",
          "Animations (object effects, custom animation)",
          "Slide Show (start from beginning/current, setup)",
          "Narration & Rehearse Timings",
          "Speaker Notes",
          "Printing & Print Preview",
          "Package Presentation for CD/Folder",
          "Spell Check",
        ])
        s.addNotes("List of competencies to demonstrate in Lab 4.")
        addFooter(s)
      }

      // 3) Insert Table (steps + sample data)
      {
        const s = pptx.addSlide()
        s.background = { color: bg }
        addTitle(s, "Insert a Table")
        addBullets(s, [
          "Insert Tab → Table → choose rows/columns",
          "Alternatively: Insert Table... → enter rows & columns",
          "Draw Table or Insert Excel Spreadsheet",
          "Place cursor in cell and begin typing",
        ])

        const rows = [
          [
            { text: "Item", options: { bold: true, color: "FFFFFF" } },
            { text: "Qty", options: { bold: true, color: "FFFFFF" } },
            { text: "Unit Price", options: { bold: true, color: "FFFFFF" } },
            { text: "Total", options: { bold: true, color: "FFFFFF" } },
          ],
          ["Notebooks", "10", "$2.00", "$20.00"],
          ["Pens", "15", "$0.50", "$7.50"],
          ["Folders", "5", "$1.20", "$6.00"],
        ]
        s.addTable(rows, {
          x: 0.7,
          y: 3.5,
          w: 8.6,
          colW: [3.5, 1.5, 1.8, 1.8],
          border: { type: "solid", color: primary, pt: 1 },
          fill: { color: "F1F5FF" },
          // Header row style
          rowH: 0.5,
          // @ts-ignore typed at runtime
          headerRow: true,
          autoPage: true,
        })
        s.addNotes("Demonstrate inserting a table and basic data entry.")
        addFooter(s)
      }

      // 4) Modify Table
      {
        const s = pptx.addSlide()
        s.background = { color: bg }
        addTitle(s, "Modify Table Structure & Format")
        addBullets(s, [
          "Design Tab: Table Style Options, Table Styles, Borders",
          "Layout Tab: Insert/Delete Rows & Columns",
          "Merge/Split Cells and adjust Cell Size",
          "Align text and change text direction",
          "View Gridlines and open Table Properties",
        ])
        s.addNotes("Show awareness of Design and Layout tabs for table formatting.")
        addFooter(s)
      }

      // 5) Insert Chart (steps + sample chart)
      {
        const s = pptx.addSlide()
        s.background = { color: bg }
        addTitle(s, "Insert a Chart")
        addBullets(s, [
          "Insert Tab → Choose Chart Type (Column, Line, Pie, etc.)",
          "Enter labels and data in the spreadsheet",
          "Use Chart Tools to style and position",
        ])

        const data = [
          {
            name: "Attendance",
            labels: ["Week 1", "Week 2", "Week 3", "Week 4"],
            values: [22, 24, 21, 25],
          },
        ]
        // @ts-ignore ChartType available at runtime
        s.addChart(pptx.ChartType.bar, data, {
          x: 0.7,
          y: 3.5,
          w: 8.6,
          h: 3.0,
          chartTitle: "Sample Attendance",
          barDir: "col",
          valAxisTitle: "Students",
          catAxisTitle: "Weeks",
          dataLabelColor: neutral,
          dataLabelFontFace: "Arial",
          colors: [accent],
        })
        s.addNotes("Include a simple bar chart with labels and values.")
        addFooter(s)
      }

      // 6) Modify Chart
      {
        const s = pptx.addSlide()
        s.background = { color: bg }
        addTitle(s, "Modify a Chart")
        addBullets(s, [
          "Move the chart: drag or copy-paste to another slide",
          "Resize using corner handles",
          "Add/modify titles and labels (Layout tab)",
          "Use Chart Tools → Design, Layout, Format",
        ])
        s.addNotes("Emphasize layout, labels, and resizing.")
        addFooter(s)
      }

      // 7) Slide Transitions
      {
        const s = pptx.addSlide()
        s.background = { color: bg }
        addTitle(s, "Slide Transitions")
        addBullets(s, [
          "Select the slide → Animations tab → choose a transition",
          "Add sound and adjust transition speed",
          "Apply to All to set across presentation",
          "Set slide advance: on click or after a delay",
        ])
        s.addNotes("In PowerPoint, use Animations tab for transitions and timing.")
        addFooter(s)
      }

      // 8) Animations
      {
        const s = pptx.addSlide()
        s.background = { color: bg }
        addTitle(s, "Slide Animations")
        addBullets(s, [
          "Select object → Animations tab → Custom Animation",
          "Click Add Effect and choose Entrance/Emphasis/Exit",
          "Set order, timing, and triggers",
          "Tip: Reveal bullet points one by one",
        ])
        s.addNotes("Object-level animations configured in PowerPoint after insertion.")
        addFooter(s)
      }

      // 9) Slide Show Options
      {
        const s = pptx.addSlide()
        s.background = { color: bg }
        addTitle(s, "Slide Show Options")
        addBullets(s, [
          "Start From Beginning or From Current Slide",
          "Set Up Slide Show (presenter-led or kiosk)",
          "Looping and narration options",
          "Monitor and resolution settings",
        ])
        s.addNotes("Use Slide Show tab for presentation behavior and monitors.")
        addFooter(s)
      }

      // 10) Record Narration
      {
        const s = pptx.addSlide()
        s.background = { color: bg }
        addTitle(s, "Record Narration")
        addBullets(s, ["Slide Show → Record Narration", "Set Microphone Level", "Click OK and record slide-by-slide"])
        s.addNotes("Narration can be saved per-slide with audio levels adjusted.")
        addFooter(s)
      }

      // 11) Speaker Notes
      {
        const s = pptx.addSlide()
        s.background = { color: bg }
        addTitle(s, "Speaker Notes")
        addBullets(s, ["View → Notes Page", "Click 'Click to add Notes' to type", "Use notes to guide delivery"])
        s.addNotes("Example Speaker Notes: Emphasize using notes to keep slides clean while guiding talk.")
        addFooter(s)
      }

      // 12) Printing Options
      {
        const s = pptx.addSlide()
        s.background = { color: bg }
        addTitle(s, "Printing Options")
        addBullets(s, [
          "Slides: one per page",
          "Handouts: 1/2/3/4/6/9 per page",
          "Notes Page: slide + notes",
          "Outline View: outline only",
          "Office Button → Print / Print Preview → choose 'Print what'",
        ])
        s.addNotes("Select appropriate print layout for audience materials.")
        addFooter(s)
      }

      // 13) Package Presentation
      {
        const s = pptx.addSlide()
        s.background = { color: bg }
        addTitle(s, "Package a Presentation")
        addBullets(s, ["Office Button → Publish → Package for CD", "Name the package", "Copy to CD or Copy to Folder"])
        s.addNotes("Package bundles the presentation with linked files.")
        addFooter(s)
      }

      // 14) Spell Check
      {
        const s = pptx.addSlide()
        s.background = { color: bg }
        addTitle(s, "Spell Check")
        addBullets(s, ["Review Tab → Proofing group → Spelling", "Fix typos across slides, notes, and handouts"])
        s.addNotes("Run a global spell check before finalizing.")
        addFooter(s)
      }

      // 15) Conclusion
      {
        const s = pptx.addSlide()
        s.background = { color: bg }
        addTitle(s, "Conclusion")
        addBullets(s, [
          "You can create and format tables",
          "You can insert and modify charts",
          "You can apply transitions and animations",
          "You can set up slide shows, narrate, rehearse, and print",
          "You can package and spell-check presentations",
        ])
        s.addNotes("Summarize competencies demonstrated in Lab 4.")
        addFooter(s)
      }

      // 16) References
      {
        const s = pptx.addSlide()
        s.background = { color: bg }
        addTitle(s, "References")
        addBullets(s, [
          "Microsoft PowerPoint Help and Support",
          "Course Handouts (Lab 4: Tables, Charts, Transitions, Animations, Printing)",
          "UET Taxila – Application of Information and Communication",
        ])
        s.addNotes("List general sources used to build the presentation.")
        addFooter(s)
      }

      await pptx.writeFile({
        fileName: "MS PowerPoint – Lab 4 – Muhammad Saif Amir – 25-ENV-56.pptx",
      })
    } finally {
      setDownloading(false)
    }
  }

  return (
    <main className="min-h-dvh flex items-center justify-center p-6">
      <div className="w-full max-w-2xl rounded-lg border bg-card p-6 shadow-sm">
        <h1 className="text-2xl font-semibold text-balance text-primary mb-2">MS PowerPoint – Lab 4 (UET Taxila)</h1>
        <p className="text-muted-foreground mb-6">
          Click the button below to generate and download a complete, professional PPTX that follows the assignment
          instructions with cover details, tables, charts, transitions (where supported), animations guidance, notes,
          printing, packaging, and spell check slides.
        </p>
        <div className="flex gap-3">
          <Button onClick={handleDownloadPptx} disabled={downloading}>
            {downloading ? "Preparing..." : "Download PPTX"}
          </Button>
        </div>
      </div>
    </main>
  )
}
